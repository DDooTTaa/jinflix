import React from "react";
import "./loader.css";

export default () => (
    <body>
    <div class="container">
        <div class="loader">
            <span>
            </span>
        </div>
    </div>
</body>
);


